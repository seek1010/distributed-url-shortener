import { CloudFrontRequestHandler } from 'aws-lambda';
export declare const handler: CloudFrontRequestHandler;
